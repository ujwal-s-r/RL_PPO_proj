"""Pydantic data models and schemas for OpenEnv communication and RL observations."""

from __future__ import annotations
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class SchedulingAction(BaseModel):
    """Action representing placement of queued job onto a cluster node."""
    job_index: int = Field(..., ge=0, description="Index of job within queue (0 to max_queue_size-1)")
    node_index: int = Field(..., ge=0, description="Index of target cluster node (0 to num_nodes-1)")


class StepResponse(BaseModel):
    """Response returned after environment step execution."""
    observation: List[float] = Field(..., description="Flattened numeric observation vector")
    reward: float = Field(..., description="Scalar step reward")
    terminated: bool = Field(..., description="Whether episode reached terminal state")
    truncated: bool = Field(..., description="Whether episode reached max horizon truncation")
    action_mask: List[List[float]] = Field(..., description="2D action feasibility mask (max_queue x num_nodes)")
    info: Dict[str, Any] = Field(default_factory=dict, description="Diagnostic metrics and metadata")


class ResetResponse(BaseModel):
    """Response returned upon environment reset."""
    observation: List[float] = Field(..., description="Initial flattened numeric observation vector")
    action_mask: List[List[float]] = Field(..., description="Initial 2D action feasibility mask")
    info: Dict[str, Any] = Field(default_factory=dict, description="Initial environment metadata")


class EnvInfoResponse(BaseModel):
    """Environment specification and metadata."""
    name: str = "gpu-scheduler-env"
    version: str = "0.1.0"
    num_nodes: int
    max_queue_size: int
    action_space_dim: int
    observation_dim: int
    cluster_gpus: int
    cluster_vram_gb: float
