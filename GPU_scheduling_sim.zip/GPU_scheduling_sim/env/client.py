"""OpenEnv client for local in-process and remote HTTP interactions."""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np

from env.models import SchedulingAction
from env.server.gpu_scheduler_environment import GPUSchedulerEnvironment


class OpenEnvClient:
    """
    Client for interacting with GPUSchedulerEnvironment.
    
    Supports high-speed in-process direct execution as well as
    optional remote HTTP client execution.
    """

    def __init__(
        self,
        env: Optional[GPUSchedulerEnvironment] = None,
        base_url: Optional[str] = None,
        **env_kwargs: Any,
    ) -> None:
        self.base_url = base_url
        if base_url is None:
            self.env = env or GPUSchedulerEnvironment(**env_kwargs)
        else:
            self.env = None

    @property
    def action_dim(self) -> int:
        if self.env is not None:
            return self.env.action_dim
        return 0

    @property
    def obs_dim(self) -> int:
        if self.env is not None:
            return self.env.obs_dim
        return 0

    def reset(
        self,
        seed: Optional[int] = 42,
        scenario: str = "balanced",
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Reset the environment."""
        if self.env is not None:
            return self.env.reset(seed=seed, options={"scenario": scenario})
        raise NotImplementedError("Remote HTTP client requires requests or httpx installed.")

    def step(
        self,
        action: Union[int, Tuple[int, int], SchedulingAction],
    ) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """Step the environment."""
        if self.env is not None:
            return self.env.step(action)
        raise NotImplementedError("Remote HTTP client requires requests or httpx installed.")

    def get_action_mask(self) -> np.ndarray:
        """Get 1D action feasibility mask."""
        if self.env is not None:
            return self.env.get_action_mask()
        return np.array([])
