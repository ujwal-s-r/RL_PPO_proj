"""FastAPI server application exposing GPUSchedulerEnvironment for OpenEnv."""

from __future__ import annotations
from typing import Any, Dict, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from env.models import SchedulingAction, StepResponse, ResetResponse, EnvInfoResponse
from env.server.gpu_scheduler_environment import GPUSchedulerEnvironment


class ResetRequest(BaseModel):
    seed: Optional[int] = 42
    scenario: Optional[str] = "balanced"


app = FastAPI(
    title="GPU Scheduler OpenEnv Server",
    description="OpenEnv service interface for RL GPU cluster scheduling",
    version="0.1.0",
)

# Global environment instance (can be re-initialized or configured on startup)
env = GPUSchedulerEnvironment()


@app.get("/health")
def health_check() -> Dict[str, str]:
    """Health check endpoint."""
    return {"status": "ok", "service": "gpu-scheduler-openenv"}


@app.get("/info", response_model=EnvInfoResponse)
def get_env_info() -> EnvInfoResponse:
    """Return environment metadata, dimensions, and action spaces."""
    return EnvInfoResponse(
        name="gpu-scheduler-env",
        version="0.1.0",
        num_nodes=env.num_nodes,
        max_queue_size=env.max_queue_size,
        action_space_dim=env.action_dim,
        observation_dim=env.obs_dim,
        cluster_gpus=env.cluster.total_gpus,
        cluster_vram_gb=env.cluster.total_vram_gb,
    )


@app.post("/reset", response_model=ResetResponse)
def reset_env(req: ResetRequest) -> ResetResponse:
    """Reset the environment with a given seed and scenario."""
    obs, info = env.reset(seed=req.seed, options={"scenario": req.scenario})
    return ResetResponse(
        observation=obs.tolist(),
        action_mask=info["action_mask_2d"],
        info={"scenario": req.scenario, "seed": req.seed},
    )


@app.post("/step", response_model=StepResponse)
def step_env(action: SchedulingAction) -> StepResponse:
    """Execute a scheduling action and advance simulation state."""
    obs, reward, terminated, truncated, info = env.step(action)
    return StepResponse(
        observation=obs.tolist(),
        reward=reward,
        terminated=terminated,
        truncated=truncated,
        action_mask=info["action_mask_2d"],
        info=info,
    )


@app.get("/action_mask")
def get_action_mask() -> Dict[str, Any]:
    """Retrieve current 2D action mask."""
    return {
        "action_mask_1d": env.get_action_mask().tolist(),
        "action_mask_2d": env.get_action_mask_2d().tolist(),
    }
