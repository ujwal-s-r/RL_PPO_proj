"""OpenEnv / Gymnasium-compatible GPU Cluster Scheduling Environment."""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple, Union
import os
import yaml
import numpy as np
import gymnasium as gym
from gymnasium import spaces

from simulator.cluster import Cluster
from simulator.simulator import Simulator
from simulator.scheduler_state import SchedulerState
from simulator.job import Job, WorkloadType
from workloads.scenarios import get_scenario, create_scenario_workload
from workloads.generators import WorkloadConfig, WorkloadGenerator
from env.models import SchedulingAction


# Mapping of WorkloadType enum to numeric index
WORKLOAD_TYPE_MAP = {
    WorkloadType.TRAINING: 0,
    WorkloadType.FINE_TUNING: 1,
    WorkloadType.EVALUATION: 2,
    WorkloadType.INFERENCE: 3,
    WorkloadType.EXPERIMENT: 4,
}


class GPUSchedulerEnvironment(gym.Env):
    """
    Gymnasium environment interface for PPO cluster scheduling.
    
    Action Space:
        Discrete(max_queue_size * num_nodes) representing flattened (job_idx, node_idx).
        
    Observation Space:
        Box(low=0.0, high=1.0, shape=(obs_dim,), dtype=np.float32)
    """

    metadata = {"render_modes": ["human"]}

    def __init__(
        self,
        cluster_config_path: str = "configs/cluster_small.yaml",
        reward_config_path: str = "configs/reward.yaml",
        scenario_name: str = "balanced",
        max_nodes: int = 8,
        max_queue_size: int = 16,
        horizon_seconds: float = 3600.0,
        cluster: Optional[Cluster] = None,
    ) -> None:
        super().__init__()

        self.cluster_config_path = cluster_config_path
        self.reward_config_path = reward_config_path
        self.scenario_name = scenario_name
        self.max_nodes = max_nodes
        self.max_queue_size = max_queue_size
        self.horizon_seconds = horizon_seconds

        # Load configurations or default dynamic cluster
        if cluster is not None:
            self.cluster = cluster
        else:
            self.cluster = Cluster.from_yaml(self.cluster_config_path)

        self.reward_config = self._load_reward_config(self.reward_config_path)

        # Simulator instance
        self.simulator = Simulator(
            cluster=self.cluster,
            max_queue_size=self.max_queue_size,
            horizon_seconds=self.horizon_seconds,
        )

        self.num_nodes = self.cluster.num_nodes
        self.action_dim = self.max_queue_size * self.max_nodes

        # Calculate observation dimension (10 fixed node slots * 8 + 16 queue slots * 9 + 7 globals = 231)
        self.node_feat_dim = 8
        self.queue_feat_dim = 9
        self.global_feat_dim = 7
        self.obs_dim = (self.max_nodes * self.node_feat_dim) + (self.max_queue_size * self.queue_feat_dim) + self.global_feat_dim

        # Gymnasium Spaces
        self.action_space = spaces.Discrete(self.action_dim)
        self.observation_space = spaces.Box(
            low=0.0,
            high=10.0,
            shape=(self.obs_dim,),
            dtype=np.float32,
        )

        self._current_seed = 42

    def _load_reward_config(self, path: str) -> Dict[str, float]:
        """Load reward hyperparameter coefficients."""
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        return {
            "completion_weight": 2.5,
            "waiting_weight": 0.008,
            "idle_gpu_weight": 0.015,
            "deadline_miss_weight": 3.5,
            "invalid_action_penalty": 2.0,
            "step_penalty": 0.001,
            "fragmentation_bonus_weight": 0.25,
            "turnaround_efficiency_weight": 0.50,
        }

    def decode_action(self, flat_action: int) -> Tuple[int, int]:
        """Convert scalar discrete action into (job_index, node_index)."""
        job_idx = flat_action // self.max_nodes
        node_idx = flat_action % self.max_nodes
        return job_idx, node_idx

    def encode_action(self, job_idx: int, node_idx: int) -> int:
        """Convert (job_index, node_index) into scalar action."""
        return (job_idx * self.max_nodes) + node_idx

    def get_action_mask(self) -> np.ndarray:
        """
        Get flattened 1D action mask of length (max_queue_size * max_nodes).
        Unused/padded node slots receive strict 0.0 mask.
        """
        mask_2d = self.simulator.get_state().get_action_mask(max_nodes=self.max_nodes)
        return mask_2d.flatten()

    def get_action_mask_2d(self) -> np.ndarray:
        """Get 2D action mask of shape (max_queue_size, max_nodes)."""
        return self.simulator.get_state().get_action_mask(max_nodes=self.max_nodes)

    def _extract_observation(self, state: SchedulerState) -> np.ndarray:
        """Vectorize simulator state into fixed 231-dim observation vector."""
        obs = np.zeros(self.obs_dim, dtype=np.float32)
        idx = 0

        # 1. Node Features (10 fixed slots * 8 features = 80)
        for slot_i in range(self.max_nodes):
            if slot_i < state.cluster.num_nodes:
                node = state.cluster.nodes[slot_i]
                free_gpus_norm = node.available_gpu_count / max(1, node.gpu_count)
                gpu_util = node.gpu_utilization
                vram_util = node.vram_utilization
                free_vram_norm = node.free_vram_gb / 80.0
                total_vram_norm = node.vram_per_gpu_gb / 80.0
                total_gpu_norm = node.gpu_count / 8.0
                running_jobs_norm = min(1.0, len(node.running_jobs) / 16.0)
                node_id_norm = (node.node_id + 1.0) / 10.0

                node_feats = [
                    free_gpus_norm,
                    gpu_util,
                    vram_util,
                    free_vram_norm,
                    total_vram_norm,
                    total_gpu_norm,
                    running_jobs_norm,
                    node_id_norm,
                ]
            else:
                # Padded absent node slot
                node_feats = [0.0] * self.node_feat_dim

            obs[idx : idx + len(node_feats)] = node_feats
            idx += len(node_feats)

        # 2. Queue Features (16 fixed slots * 9 features = 144)
        for slot_idx in range(self.max_queue_size):
            job = state.queue.get_at(slot_idx)
            if job is not None:
                job_present = 1.0
                gpu_req_norm = job.gpu_count / 8.0
                vram_req_norm = job.vram_per_gpu_gb / 80.0
                est_runtime_norm = min(2.0, job.estimated_runtime / 600.0)
                priority_norm = job.priority / 10.0
                wait_time_norm = min(2.0, (state.current_time - job.arrival_time) / 600.0)
                remaining_deadline = max(0.0, job.deadline - state.current_time)
                deadline_norm = min(2.0, remaining_deadline / 1200.0)
                wtype_idx = WORKLOAD_TYPE_MAP.get(job.workload_type, 0) / 5.0
                is_tight = 1.0 if remaining_deadline < (job.estimated_runtime * 1.5) else 0.0

                q_feats = [
                    job_present,
                    gpu_req_norm,
                    vram_req_norm,
                    est_runtime_norm,
                    priority_norm,
                    wait_time_norm,
                    deadline_norm,
                    wtype_idx,
                    is_tight,
                ]
            else:
                q_feats = [0.0] * self.queue_feat_dim

            obs[idx : idx + len(q_feats)] = q_feats
            idx += len(q_feats)

        # 3. Global Features + Future Arrival Lookahead Hints (7)
        sim_time_norm = min(1.0, state.current_time / max(1.0, self.horizon_seconds))
        queue_len_norm = len(state.queue) / max(1, self.max_queue_size)
        cluster_gpu_util = state.cluster.gpu_utilization
        cluster_vram_util = state.cluster.vram_utilization

        next_dt, next_gpus, next_vram = state.next_arrival
        next_dt_norm = min(1.0, next_dt / 60.0)
        next_gpus_norm = next_gpus / 8.0
        next_vram_norm = next_vram / 80.0

        global_feats = [
            sim_time_norm,
            queue_len_norm,
            cluster_gpu_util,
            cluster_vram_util,
            next_dt_norm,
            next_gpus_norm,
            next_vram_norm,
        ]
        obs[idx : idx + len(global_feats)] = global_feats

        return obs

    def reset(
        self,
        *,
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Reset environment and initialize workload."""
        super().reset(seed=seed)
        if seed is not None:
            self._current_seed = seed

        scenario = options.get("scenario", self.scenario_name) if options else self.scenario_name
        self.scenario_name = scenario

        # Dynamic cluster topology support
        if options and "cluster" in options:
            self.cluster = options["cluster"]
            self.simulator.cluster = self.cluster
        elif options and options.get("random_topology", False):
            self.cluster = Cluster.create_random(seed=self._current_seed)
            self.simulator.cluster = self.cluster

        self.num_nodes = self.cluster.num_nodes

        # Reset cluster and simulator state
        initial_state = self.simulator.reset()

        # Generate and load scenario workload with capacity feasibility clamping
        raw_jobs = create_scenario_workload(self.scenario_name, seed=self._current_seed)
        max_cluster_gpus_per_node = max((n.gpu_count for n in self.cluster.nodes), default=8)
        max_cluster_vram = max((n.vram_per_gpu_gb for n in self.cluster.nodes), default=80.0)

        jobs = []
        for j in raw_jobs:
            j.gpu_count = max(1, min(j.gpu_count, max_cluster_gpus_per_node))
            j.vram_per_gpu_gb = min(j.vram_per_gpu_gb, max_cluster_vram)
            jobs.append(j)

        self.simulator.load_workload(jobs)

        # Step until first scheduling decision point
        done, _ = self.simulator.step_to_next_decision()

        state = self.simulator.get_state()
        obs = self._extract_observation(state)
        info = {
            "scenario": self.scenario_name,
            "seed": self._current_seed,
            "action_mask": self.get_action_mask(),
            "action_mask_2d": self.get_action_mask_2d().tolist(),
            "is_terminal": done,
        }
        return obs, info

    def step(
        self,
        action: Union[int, Tuple[int, int], SchedulingAction],
    ) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """
        Execute one scheduling decision step.
        
        Args:
            action: Either flat integer index or (job_index, node_index) tuple.
            
        Returns:
            (observation, reward, terminated, truncated, info)
        """
        if isinstance(action, SchedulingAction):
            job_idx, node_idx = action.job_index, action.node_index
        elif isinstance(action, (tuple, list)):
            job_idx, node_idx = int(action[0]), int(action[1])
        else:
            job_idx, node_idx = self.decode_action(int(action))

        # Record simulation timestamp before step
        t_before = self.simulator.current_time

        # 1. Apply Action
        valid_placement = self.simulator.apply_action(job_idx, node_idx)

        # 2. Advance event queue until next decision point or horizon
        done, completed_in_step = self.simulator.step_to_next_decision()
        t_after = self.simulator.current_time
        dt = max(0.0, t_after - t_before)
        dt_scale = min(10.0, dt / 10.0) # normalized time interval (1.0 = 10s of elapsed time)

        # 3. Compute Decima Time-Integrated Shaped Reward
        reward = 0.0
        r_cfg = self.reward_config

        if not valid_placement:
            # Penalize invalid action attempts
            reward -= float(r_cfg.get("invalid_action_penalty", 2.00))
        else:
            # Anti-fragmentation bin-pack bonus (if node is now fully occupied with 0 stranded GPUs)
            node = self.cluster.get_node(node_idx)
            if node is not None and node.available_gpu_count == 0:
                reward += float(r_cfg.get("fragmentation_bonus_weight", 0.50))

        # 1. Continuous Time-Integrated Active GPU Utilization Reward
        cluster_util = self.cluster.gpu_utilization
        reward += float(r_cfg.get("utilization_weight", 2.00)) * cluster_util * dt_scale

        # 2. Priority-weighted Completion & Turnaround Efficiency Bonuses
        comp_weight = float(r_cfg.get("completion_weight", 1.50))
        eff_weight = float(r_cfg.get("turnaround_efficiency_weight", 1.50))
        sla_weight = float(r_cfg.get("deadline_miss_weight", 4.00))

        for comp_job in completed_in_step:
            prio_factor = comp_job.priority / 5.0
            reward += comp_weight * prio_factor

            if comp_job.turnaround_time and comp_job.turnaround_time > 0:
                eff_ratio = comp_job.actual_runtime / comp_job.turnaround_time
                reward += eff_weight * eff_ratio * prio_factor

            if comp_job.is_deadline_missed():
                reward -= sla_weight * prio_factor

        # 3. Time-Integrated Queue Slowdown Penalty
        slowdown_weight = float(r_cfg.get("slowdown_penalty_weight", 0.10))
        slowdown_rate = 0.0
        for q_job in self.simulator.queue:
            prio_scale = q_job.priority / 5.0
            norm_wait_rate = 1.0 / max(10.0, q_job.estimated_runtime)
            slowdown_rate += (norm_wait_rate * prio_scale)

        reward -= slowdown_weight * min(10.0, slowdown_rate * dt_scale)
        reward -= float(r_cfg.get("step_penalty", 0.005))

        # Check truncation vs termination
        terminated = done and (self.simulator.current_time >= self.horizon_seconds or len(self.simulator.event_queue) == 0)
        truncated = self.simulator.current_time >= self.horizon_seconds

        state = self.simulator.get_state()
        obs = self._extract_observation(state)
        
        info = {
            "valid_action": valid_placement,
            "action_mask": self.get_action_mask(),
            "action_mask_2d": self.get_action_mask_2d().tolist(),
            "completed_step_count": len(completed_in_step),
            "sim_time": self.simulator.current_time,
            "metrics": self.simulator.get_metrics() if done else {},
        }
        return obs, reward, terminated, truncated, info
