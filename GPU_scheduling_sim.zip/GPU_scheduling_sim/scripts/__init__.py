"""Execution and training scripts."""
