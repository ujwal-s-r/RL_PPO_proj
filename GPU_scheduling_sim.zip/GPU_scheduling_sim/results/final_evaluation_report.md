# Final Evaluation Benchmark: PPO vs Classical Schedulers

### Scenario: Balanced

| Metric                 | FIFO   | SJF    | Priority | BestFit | PPO    |
| ---------------------- | ------ | ------ | -------- | ------- | ------ |
| Mean JCT (s)           | 269.70 | 264.27 | 260.28   | 262.30  | 266.55 |
| P95 JCT (s)            | 810.71 | 819.89 | 659.33   | 744.84  | 855.00 |
| Mean Queue Wait (s)    | 151.21 | 148.75 | 142.54   | 143.36  | 145.44 |
| GPU Utilization (%)    | 36.87% | 30.22% | 31.80%   | 33.26%  | 45.84% |
| Throughput (jobs/hr)   | 49.33  | 40.67  | 41.33    | 43.00   | 54.67  |
| Deadline Violation (%) | 29.60% | 25.45% | 27.99%   | 34.26%  | 23.45% |
| Completed Jobs         | 49     | 40     | 41       | 43      | 54     |
| Cumulative Reward      | 50.64  | 47.23  | 44.44    | 37.62   | 65.86  |

### Scenario: Training_heavy

| Metric                 | FIFO    | SJF     | Priority | BestFit | PPO     |
| ---------------------- | ------- | ------- | -------- | ------- | ------- |
| Mean JCT (s)           | 941.15  | 995.95  | 882.56   | 980.36  | 1160.55 |
| P95 JCT (s)            | 1732.46 | 2084.56 | 1600.11  | 1721.09 | 2447.67 |
| Mean Queue Wait (s)    | 580.34  | 594.70  | 501.41   | 612.31  | 734.99  |
| GPU Utilization (%)    | 32.22%  | 36.28%  | 37.13%   | 33.12%  | 38.10%  |
| Throughput (jobs/hr)   | 8.67    | 9.00    | 9.00     | 8.67    | 9.00    |
| Deadline Violation (%) | 39.47%  | 42.32%  | 30.51%   | 42.12%  | 36.11%  |
| Completed Jobs         | 8       | 9       | 9        | 8       | 9       |
| Cumulative Reward      | 6.51    | 5.15    | 9.12     | 5.51    | 7.11    |

### Scenario: Short_job_heavy

| Metric                 | FIFO   | SJF     | Priority | BestFit | PPO     |
| ---------------------- | ------ | ------- | -------- | ------- | ------- |
| Mean JCT (s)           | 68.46  | 47.79   | 55.49    | 66.58   | 46.81   |
| P95 JCT (s)            | 188.24 | 108.91  | 116.65   | 185.42  | 97.65   |
| Mean Queue Wait (s)    | 40.22  | 19.82   | 27.22    | 38.43   | 18.73   |
| GPU Utilization (%)    | 93.06% | 88.26%  | 90.17%   | 93.49%  | 88.71%  |
| Throughput (jobs/hr)   | 681.33 | 676.33  | 671.67   | 686.67  | 670.67  |
| Deadline Violation (%) | 27.30% | 8.87%   | 13.29%   | 28.95%  | 11.26%  |
| Completed Jobs         | 681    | 676     | 671      | 686     | 670     |
| Cumulative Reward      | 772.80 | 1135.29 | 1038.08  | 744.57  | 1076.10 |

### Scenario: Bursty

| Metric                 | FIFO   | SJF    | Priority | BestFit | PPO    |
| ---------------------- | ------ | ------ | -------- | ------- | ------ |
| Mean JCT (s)           | 195.89 | 174.25 | 211.80   | 176.47  | 191.60 |
| P95 JCT (s)            | 541.19 | 533.20 | 633.16   | 539.79  | 631.90 |
| Mean Queue Wait (s)    | 108.81 | 82.89  | 109.15   | 92.49   | 101.21 |
| GPU Utilization (%)    | 25.31% | 24.07% | 32.36%   | 21.01%  | 21.01% |
| Throughput (jobs/hr)   | 39.33  | 36.33  | 45.33    | 39.00   | 33.00  |
| Deadline Violation (%) | 35.97% | 20.42% | 26.48%   | 33.57%  | 26.28% |
| Completed Jobs         | 39     | 36     | 45       | 39      | 33     |
| Cumulative Reward      | 32.74  | 47.03  | 51.15    | 37.06   | 37.55  |

### Scenario: Gpu_fragmentation

| Metric                 | FIFO   | SJF    | Priority | BestFit | PPO    |
| ---------------------- | ------ | ------ | -------- | ------- | ------ |
| Mean JCT (s)           | 203.26 | 221.95 | 231.88   | 219.92  | 213.32 |
| P95 JCT (s)            | 513.29 | 563.87 | 637.49   | 532.41  | 625.92 |
| Mean Queue Wait (s)    | 94.66  | 112.04 | 123.34   | 108.35  | 103.22 |
| GPU Utilization (%)    | 15.02% | 16.70% | 17.49%   | 18.64%  | 17.41% |
| Throughput (jobs/hr)   | 20.00  | 21.33  | 22.00    | 22.33   | 21.67  |
| Deadline Violation (%) | 22.12% | 21.85% | 23.96%   | 22.24%  | 20.03% |
| Completed Jobs         | 20     | 21     | 22       | 22      | 21     |
| Cumulative Reward      | 23.49  | 25.04  | 24.27    | 24.98   | 27.63  |

### Scenario: High_load

| Metric                 | FIFO   | SJF    | Priority | BestFit | PPO     |
| ---------------------- | ------ | ------ | -------- | ------- | ------- |
| Mean JCT (s)           | 282.72 | 270.72 | 293.37   | 304.28  | 307.34  |
| P95 JCT (s)            | 917.80 | 748.03 | 836.52   | 707.76  | 1061.67 |
| Mean Queue Wait (s)    | 147.49 | 142.94 | 159.74   | 165.81  | 175.97  |
| GPU Utilization (%)    | 39.62% | 24.76% | 29.75%   | 36.36%  | 33.84%  |
| Throughput (jobs/hr)   | 43.67  | 27.67  | 32.67    | 37.00   | 33.67   |
| Deadline Violation (%) | 24.10% | 23.69% | 27.18%   | 36.67%  | 22.95%  |
| Completed Jobs         | 43     | 27     | 32       | 37      | 33      |
| Cumulative Reward      | 53.71  | 33.09  | 35.65    | 30.94   | 41.54   |